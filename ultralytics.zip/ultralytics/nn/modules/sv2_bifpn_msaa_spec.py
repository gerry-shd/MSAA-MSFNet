# -*- coding: utf-8 -*-
# SV2 + BiFPN + MSAA (+ Spectral Split & Gate) unified backbone
# 说明：
#  - 融合了频域增强（SSG）到原始 SV2_BiFPN_MSAA 内部，不依赖其它模块导入
#  - 同时支持 torchvision 与 timm 预训练模型（含离线本地权重路径）
#  - 作为 Ultralytics backbone：width_list / forward 返回结构兼容 parse_model

import os
import math
from typing import List, Tuple, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

# -------------------- 可选：torchvision 作为 backbone 源 --------------------
_HAS_TV = True
try:
    from torchvision.models import (
        shufflenet_v2_x0_5, shufflenet_v2_x1_0, shufflenet_v2_x1_5, shufflenet_v2_x2_0,
        mobilenet_v3_large, efficientnet_v2_s, convnext_tiny
    )
    # 权重枚举（不同版本 torchvision 字段名略有差异，做保护）
    try:
        from torchvision.models.shufflenetv2 import (
            ShuffleNet_V2_X0_5_Weights, ShuffleNet_V2_X1_0_Weights,
            ShuffleNet_V2_X1_5_Weights, ShuffleNet_V2_X2_0_Weights
        )
    except Exception:
        ShuffleNet_V2_X0_5_Weights = ShuffleNet_V2_X1_0_Weights = \
        ShuffleNet_V2_X1_5_Weights = ShuffleNet_V2_X2_0_Weights = None

    try:
        from torchvision.models.mobilenetv3 import MobileNet_V3_Large_Weights
    except Exception:
        MobileNet_V3_Large_Weights = None

    try:
        from torchvision.models.efficientnet import EfficientNet_V2_S_Weights
    except Exception:
        EfficientNet_V2_S_Weights = None

    try:
        from torchvision.models.convnext import ConvNeXt_Tiny_Weights
    except Exception:
        ConvNeXt_Tiny_Weights = None
except Exception:
    _HAS_TV = False

# -------------------- 可选：timm 作为 backbone 源 --------------------
_HAS_TIMM = True
try:
    import timm
except Exception:
    _HAS_TIMM = False


# -------------------- 基础算子 --------------------
class ConvBNAct(nn.Module):
    def __init__(self, c1, c2, k=1, s=1, p=None, groups=1, act=True):
        super().__init__()
        if p is None:
            p = (k - 1) // 2
        self.conv = nn.Conv2d(c1, c2, k, s, p, groups=groups, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU(inplace=True) if act else nn.Identity()

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))


def resize_to(x, ref, mode="nearest"):
    return x if x.shape[-2:] == ref.shape[-2:] else F.interpolate(x, size=ref.shape[-2:], mode=mode)


import os, torch
from collections import OrderedDict

def _read_local_ckpt(path: str):
    if path.endswith(".safetensors"):
        from safetensors.torch import load_file
        sd = load_file(path)
    else:
        obj = torch.load(path, map_location="cpu")
        sd = obj.get("state_dict", obj)
    # 去掉常见前缀
    new_sd = OrderedDict()
    for k, v in sd.items():
        if k.startswith("module."): k = k[7:]
        if k.startswith("model."):  k = k[6:]
        new_sd[k] = v
    return new_sd

def _strip_classifier(sd: dict):
    # 丢弃分类头/池化等与骨干无关的权重
    drop_prefixes = ("head.", "fc.", "classifier.", "norm_pre.", "global_pool.")
    return {k: v for k, v in sd.items() if not k.startswith(drop_prefixes)}

def _rename_for_featurelist(sd: dict):
    # 将 ConvNeXt(v2) 这类权重的 "stem.0"→"stem_0", "stages.1"→"stages_1"
    renamed = OrderedDict()
    for k, v in sd.items():
        if k.startswith("stem."):
            parts = k.split(".")           # stem.0.weight  -> ['stem','0','weight']
            k = f"stem_{parts[1]}." + ".".join(parts[2:]) if len(parts) > 2 else f"stem_{parts[1]}"
        elif k.startswith("stages.") and k.split(".")[1].isdigit():
            parts = k.split(".")           # stages.1.blocks.0.conv_dw.weight
            k = f"stages_{parts[1]}." + ".".join(parts[2:])
        renamed[k] = v
    return renamed

def load_local_to_featurelist(model, ckpt_path: str, arch_name: str, verbose=True):
    """
    model: timm 的 FeatureListNet（features_only=True 创建的对象）
    ckpt_path: 本地 timm 权重（.pth/.pt/.bin/.safetensors）
    arch_name: 例如 'convnextv2_tiny'（仅用于日志提示）
    """
    if not (isinstance(ckpt_path, str) and os.path.isfile(ckpt_path)):
        if verbose:
            print(f"[load_local_to_featurelist] 跳过：{ckpt_path} 不存在。")
        return

    sd = _read_local_ckpt(ckpt_path)
    sd = _strip_classifier(sd)
    sd = _rename_for_featurelist(sd)

    msd = model.state_dict()
    inter = {k: v for k, v in sd.items() if k in msd and v.shape == msd[k].shape}

    msg = model.load_state_dict(inter, strict=False)
    if verbose:
        print(f"[{arch_name}] 从本地权重加载: {ckpt_path}")
        print(f"  - 成功加载 {len(inter)} 个匹配键")
        if msg.missing_keys:
            print(f"  - 缺失 {len(msg.missing_keys)} 键（一般是包装/头部，忽略即可）")
        if msg.unexpected_keys:
            print(f"  - 多余 {len(msg.unexpected_keys)} 键（与 FeatureListNet 无关，已忽略）")

# -------------------- MSAA：多尺度自适应注意力（输出选择器） --------------------
class ScaleSelector(nn.Module):
    def __init__(self, c: int, out_scale: str = "P4", mode: str = "softmax"):
        super().__init__()
        assert out_scale in ("P3", "P4", "P5")
        assert mode in ("softmax", "fixed", "avg")
        self.out_scale, self.mode = out_scale, mode
        cr = max(c // 16, 1)
        self.score = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(c, cr, 1, bias=False), nn.ReLU(inplace=True),
            nn.Conv2d(cr, 1, 1, bias=True)
        )

    def forward(self, P3, P4, P5):
        if self.mode == "fixed":
            return {"P3": P3, "P4": P4, "P5": P5}[self.out_scale]
        if self.mode == "avg":
            ref = {"P3": P3, "P4": P4, "P5": P5}[self.out_scale]
            return (resize_to(P3, ref) + resize_to(P4, ref) + resize_to(P5, ref)) / 3.0

        s3, s4, s5 = self.score(P3), self.score(P4), self.score(P5)
        w = torch.softmax(torch.cat([s3, s4, s5], dim=1), dim=1)  # [B,3,1,1]
        if self.out_scale == "P3":
            ref = P3; P4r, P5r = resize_to(P4, ref), resize_to(P5, ref)
            return w[:,0:1]*P3 + w[:,1:2]*P4r + w[:,2:3]*P5r
        if self.out_scale == "P4":
            ref = P4; P3r, P5r = resize_to(P3, ref), resize_to(P5, ref)
            return w[:,0:1]*P3r + w[:,1:2]*P4 + w[:,2:3]*P5r
        ref = P5; P3r, P4r = resize_to(P3, ref), resize_to(P4, ref)
        return w[:,0:1]*P3r + w[:,1:2]*P4r + w[:,2:3]*P5


# -------------------- BiFPN（加权自顶向下 + 自底向上） --------------------
class FastBNReLUConv(nn.Module):
    def __init__(self, c, act=True):
        super().__init__()
        self.conv = ConvBNAct(c, c, k=3, s=1, p=1, act=act)

    def forward(self, x):
        return self.conv(x)


class BiFPNBlock(nn.Module):
    """单层 BiFPN（weighted fusion）"""
    def __init__(self, c: int):
        super().__init__()
        # top-down
        self.p5_td = FastBNReLUConv(c)
        self.p4_td = FastBNReLUConv(c)
        self.p3_td = FastBNReLUConv(c)
        # bottom-up
        self.p3_out = FastBNReLUConv(c)
        self.p4_out = FastBNReLUConv(c)
        self.p5_out = FastBNReLUConv(c)
        # 融合权重（正归一化）
        self.eps = 1e-4
        self.w_p4_1 = nn.Parameter(torch.ones(2))
        self.w_p3_1 = nn.Parameter(torch.ones(2))
        self.w_p4_2 = nn.Parameter(torch.ones(2))
        self.w_p5_2 = nn.Parameter(torch.ones(2))

    def _norm_w(self, w: torch.Tensor):
        w = F.relu(w)
        return w / (torch.sum(w, dim=0, keepdim=True) + self.eps)

    def forward(self, P3, P4, P5):
        # Top-Down
        w = self._norm_w(self.w_p4_1); y4 = self.p4_td(w[0]*P4 + w[1]*resize_to(P5, P4))
        w = self._norm_w(self.w_p3_1); y3 = self.p3_td(w[0]*P3 + w[1]*resize_to(y4, P3))
        # Bottom-Up
        w = self._norm_w(self.w_p4_2); o4 = self.p4_out(w[0]*P4 + w[1]*resize_to(y3, P4))
        w = self._norm_w(self.w_p5_2); o5 = self.p5_out(w[0]*P5 + w[1]*resize_to(o4, P5))
        o3 = self.p3_out(y3)
        return o3, o4, o5


class BiFPN(nn.Module):
    def __init__(self, c: int, repeats: int = 3):
        super().__init__()
        repeats = max(int(repeats), 1)
        self.blocks = nn.ModuleList([BiFPNBlock(c) for _ in range(repeats)])

    def forward(self, P3, P4, P5):
        for b in self.blocks:
            P3, P4, P5 = b(P3, P4, P5)
        return P3, P4, P5


# -------------------- 频域选择性增强（SSG：多核低/高频 + 门控） --------------------
class _LowPass(nn.Module):
    def __init__(self, k: int):
        super().__init__()
        self.pool = nn.AvgPool2d(kernel_size=k, stride=1, padding=k // 2, count_include_pad=False)

    def forward(self, x):
        return self.pool(x)


class _HighPass(nn.Module):
    def __init__(self, k: int):
        super().__init__()
        self.lp = _LowPass(k)

    def forward(self, x):
        return x - self.lp(x)


class SpectralSplitGate(nn.Module):
    def __init__(self, c: int, k_list: List[int] = (3, 5, 9)):
        super().__init__()
        self.k_list = list(k_list)
        self.lows = nn.ModuleList([_LowPass(k) for k in self.k_list])
        self.highs = nn.ModuleList([_HighPass(k) for k in self.k_list])

        bands = 2 * len(self.k_list)
        hidden = max(c // 4, 8)
        self.gate = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(c * bands, hidden, 1, bias=False), nn.SiLU(inplace=True),
            nn.Conv2d(hidden, bands, 1, bias=True)
        )
        self.mix = ConvBNAct(c, c, k=1)
        self.res_alpha = nn.Parameter(torch.tensor(1.0))

    def forward(self, x):
        low_maps = [lp(x) for lp in self.lows]
        high_maps = [hp(x) for hp in self.highs]
        feat_stack = low_maps + high_maps

        stats = torch.cat([F.adaptive_avg_pool2d(f, 1) for f in feat_stack], dim=1)  # [B, C*bands, 1, 1]
        w = torch.softmax(self.gate(stats), dim=1)                                   # [B, bands, 1, 1]

        out = 0.0
        for i, f in enumerate(feat_stack):
            out = out + w[:, i:i + 1] * f

        out = self.mix(out)
        return out + self.res_alpha * x


class SpecRefine(nn.Module):
    def __init__(self, c: int, repeats: int = 1, k_list: List[int] = (3, 5, 9)):
        super().__init__()
        repeats = max(int(repeats), 0)
        self.blocks = nn.Sequential(*[SpectralSplitGate(c, k_list=k_list) for _ in range(repeats)]) if repeats > 0 else nn.Identity()

    def forward(self, x):
        return self.blocks(x)


# -------------------- 主干：ShuffleNetV2 / TV / TIMM 统一抽取 P3/P4/P5 --------------------
class _TVFeaturesMixin:
    @staticmethod
    def capture_from_features(features: nn.Sequential, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        H0, W0 = x.shape[-2:]
        targets = [8, 16, 32]
        got = [False, False, False]
        P = [None, None, None]
        y = x
        for layer in features:
            y = layer(y)
            down = max(H0 // y.shape[-2], 1)
            for k, t in enumerate(targets):
                if (not got[k]) and down >= t:
                    P[k] = y
                    got[k] = True
            if all(got):
                break
        if P[2] is None:
            P[2] = y
        if P[1] is None:
            P[1] = P[2]
        if P[0] is None:
            P[0] = P[1]
        return P[0], P[1], P[2]


# -------------------- 最终融合版本：SV2_BiFPN_MSAA（集成 SSG + 多源预训练） --------------------
class SV2_BiFPN_MSAA_SPEC(nn.Module, _TVFeaturesMixin):
    """
    YAML 用法（backbone）：
      [-1, 1, SV2_BiFPN_MSAA, [c2, width_mult, pretrained_backbone, repeats, out_scale, selector_mode, use_hkm, arch, spec_repeats, k_list]]

    参数：
      c2:               对齐后的通道数（默认 256）
      width_mult:       仅对 'sv2' 有效（0.5/1.0/1.5/2.0）
      pretrained_backbone:
                        True/False 或 本地权重路径字符串（离线加载）
      repeats:          BiFPN 重复层数
      out_scale:        'P3'/'P4'/'P5'
      selector_mode:    'softmax'（自适应）| 'fixed' | 'avg'
      use_hkm:          兼容旧参数（保留，不在本版使用，可占位）
      arch:             'sv2' | 'mbv3' | 'effv2s' | 'convnext_tiny' | 'timm:<name>'
      spec_repeats:     频域增强的重复次数（0 为关闭，做消融）
      k_list:           频域分解核尺寸列表，如 [3,5,9] 或 [3,5,9,15]
      c1:               输入通道（parse_model 可能会传入，默认 3）
    """
    def __init__(self,
                 c2: int = 256,
                 width_mult: float = 1.0,
                 pretrained_backbone: Optional[object] = True,
                 repeats: int = 3,
                 out_scale: str = "P4",
                 selector_mode: str = "softmax",
                 use_hkm: bool = True,
                 arch: str = "sv2",
                 spec_repeats: int = 2,
                 k_list: List[int] = (3, 5, 9),
                 c1: int = 3):
        super().__init__()

        self.c2 = int(c2)
        self.arch = arch.lower().strip()
        self.width_mult = float(width_mult)

        # -------- 1) 构建主干，统一输出 P3/P4/P5 --------
        if self.arch == "sv2":
            if not _HAS_TV:
                raise ImportError("需要 torchvision，请先 `pip install torchvision`。")
            # width_mult 映射到不同变体
            if abs(self.width_mult - 0.5) < 1e-6:
                weights = ShuffleNet_V2_X0_5_Weights.DEFAULT if (isinstance(pretrained_backbone, bool) and pretrained_backbone) else None
                m = shufflenet_v2_x0_5(weights=weights)
            elif abs(self.width_mult - 1.0) < 1e-6:
                weights = ShuffleNet_V2_X1_0_Weights.DEFAULT if (isinstance(pretrained_backbone, bool) and pretrained_backbone) else None
                m = shufflenet_v2_x1_0(weights=weights)
            elif abs(self.width_mult - 1.5) < 1e-6:
                weights = ShuffleNet_V2_X1_5_Weights.DEFAULT if (isinstance(pretrained_backbone, bool) and pretrained_backbone) else None
                m = shufflenet_v2_x1_5(weights=weights)
            elif abs(self.width_mult - 2.0) < 1e-6:
                weights = ShuffleNet_V2_X2_0_Weights.DEFAULT if (isinstance(pretrained_backbone, bool) and pretrained_backbone) else None
                m = shufflenet_v2_x2_0(weights=weights)
            else:
                raise ValueError("sv2 width_mult 仅支持 0.5/1.0/1.5/2.0")
            # 本地权重路径（离线）
            if isinstance(pretrained_backbone, str) and os.path.isfile(pretrained_backbone):
                sd = torch.load(pretrained_backbone, map_location="cpu")
                if isinstance(sd, dict) and "state_dict" in sd:
                    sd = sd["state_dict"]
                m.load_state_dict(sd, strict=False)

            # -------- 冻结低层，只训练高层 --------
            for param in m.parameters():
                param.requires_grad = False
            for param in m.conv5.parameters():
                param.requires_grad = True

            self.bb_kind = "tv_sv2"
            self.stem = nn.Sequential(m.conv1, m.maxpool)  # /4
            self.stage2 = m.stage2                          # /8
            self.stage3 = m.stage3                          # /16
            self.stage4 = m.stage4                          # /32
            self.conv5  = m.conv5                           # /32

        elif self.arch in {"mbv3", "effv2s", "convnext_tiny"}:
            if not _HAS_TV:
                raise ImportError("需要 torchvision，请先 `pip install torchvision`。")
            self.bb_kind = "tv_features"
            if self.arch == "mbv3":
                weights = MobileNet_V3_Large_Weights.DEFAULT if (isinstance(pretrained_backbone, bool) and pretrained_backbone) else None
                m = mobilenet_v3_large(weights=weights)
            elif self.arch == "effv2s":
                weights = EfficientNet_V2_S_Weights.DEFAULT if (isinstance(pretrained_backbone, bool) and pretrained_backbone) else None
                m = efficientnet_v2_s(weights=weights)
            else:
                weights = ConvNeXt_Tiny_Weights.DEFAULT if (isinstance(pretrained_backbone, bool) and pretrained_backbone) else None
                m = convnext_tiny(weights=weights)
            # 手动本地权重
            if isinstance(pretrained_backbone, str) and os.path.isfile(pretrained_backbone):
                sd = torch.load(pretrained_backbone, map_location="cpu")
                if isinstance(sd, dict) and "state_dict" in sd:
                    sd = sd["state_dict"]
                m.load_state_dict(sd, strict=False)
            self.features = m.features

        elif self.arch.startswith("timm:"):
            if not _HAS_TIMM:
                raise ImportError("需要 timm，请先 `pip install timm`。")
            self.bb_kind = "timm"
            name = self.arch.split(":", 1)[1]
            ckpt_path = pretrained_backbone if isinstance(pretrained_backbone, str) and os.path.isfile(pretrained_backbone) else ""
            if ckpt_path:
                # 1) 先创建 features_only 包装（不要传 checkpoint_path）
                self.timm_backbone = timm.create_model(
                    name, pretrained=False, features_only=True, out_indices=(1, 2, 3)
                )

                # 2) 再把本地权重“手动”喂进去（自动去分类头+键名映射+形状匹配）
                load_local_to_featurelist(self.timm_backbone, ckpt_path, name)
            else:
                # 在线：需要网络（或 False 为随机初始化）
                try:
                    self.timm_backbone = timm.create_model(
                        name, pretrained=bool(pretrained_backbone), features_only=True, out_indices=(1, 2, 3)
                    )
                except TypeError:
                    self.timm_backbone = timm.create_model(
                        name, pretrained=bool(pretrained_backbone), features_only=True
                    )
        else:
            raise ValueError(f"未知 arch='{arch}'，可选：'sv2'|'mbv3'|'effv2s'|'convnext_tiny'|'timm:<name>'")

        # -------- 2) 对齐通道（适配 P3/P4/P5 到 c2） --------
        self.adapt3: Optional[nn.Module] = None
        self.adapt4: Optional[nn.Module] = None
        self.adapt5: Optional[nn.Module] = None

        # -------- 3) BiFPN + 频域增强（SSG 可做消融） --------
        self.bifpn = BiFPN(self.c2, repeats=repeats)
        self.spec3 = SpecRefine(self.c2, repeats=spec_repeats, k_list=k_list)
        self.spec4 = SpecRefine(self.c2, repeats=spec_repeats, k_list=k_list)
        self.spec5 = SpecRefine(self.c2, repeats=spec_repeats, k_list=k_list)

        # -------- 4) MSAA 输出选择 --------
        self.selector = ScaleSelector(c=self.c2, out_scale=out_scale, mode=selector_mode)
        self.out_bn = nn.BatchNorm2d(self.c2)

        # parse_model 识别所需
        self.width_list = [0, self.c2, self.c2, self.c2, self.c2]

    # ---------- backbone 前向，统一得到 P3/P4/P5 ----------
    def _forward_backbone(self, x: torch.Tensor):
        if self.bb_kind == "tv_sv2":
            x = self.stem(x)        # /4
            P3 = self.stage2(x)     # /8
            P4 = self.stage3(P3)    # /16
            P5 = self.stage4(P4)    # /32
            P5 = self.conv5(P5)     # /32
            return P3, P4, P5
    # tv.features 序列
        elif self.bb_kind == "tv_features":
            return self.capture_from_features(self.features, x)
        else:  # timm
            feats = self.timm_backbone(x)
            if not isinstance(feats, (list, tuple)):
                feats = [feats]
            if len(feats) >= 3:
                P3, P4, P5 = feats[-3], feats[-2], feats[-1]
            elif len(feats) == 2:
                P3, P4 = feats[-2], feats[-1]
                P5 = F.max_pool2d(P4, kernel_size=2)
            else:
                P4 = feats[-1]
                P3 = F.interpolate(P4, scale_factor=2, mode="nearest")
                P5 = F.max_pool2d(P4, kernel_size=2)
            return P3, P4, P5

    def _build_adapters(self, c3, c4, c5, device):
        self.adapt3 = ConvBNAct(c3, self.c2, k=1, act=True).to(device)
        self.adapt4 = ConvBNAct(c4, self.c2, k=1, act=True).to(device)
        self.adapt5 = ConvBNAct(c5, self.c2, k=1, act=True).to(device)

    # ---------- 总前向 ----------
    def forward(self, x):
        # 1) 主干多尺度
        P3, P4, P5 = self._forward_backbone(x)

        # 2) 首次前向时构建通道适配
        if self.adapt3 is None:
            self._build_adapters(P3.shape[1], P4.shape[1], P5.shape[1], device=P3.device)

        # 3) 通道对齐
        P3a, P4a, P5a = self.adapt3(P3), self.adapt4(P4), self.adapt5(P5)

        # 4) BiFPN
        P3b, P4b, P5b = self.bifpn(P3a, P4a, P5a)

        # 5) 频域增强（可关：spec_repeats=0 即为 Identity）
        P3s, P4s, P5s = self.spec3(P3b), self.spec4(P4b), self.spec5(P5b)

        # 6) MSAA 输出
        Out = self.selector(P3s, P4s, P5s)
        Out = self.out_bn(Out)

        # 7) 作为 backbone 的多输出列表
        return [None, P3s, P4s, P5s, Out]
