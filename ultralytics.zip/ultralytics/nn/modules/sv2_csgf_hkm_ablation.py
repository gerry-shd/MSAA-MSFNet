# ultralytics/nn/modules/sv2_csgf_hkm.py
# -*- coding: utf-8 -*-
import math
from typing import Optional
import torch
import torch.nn as nn
import torch.nn.functional as F

# ----------------- ShuffleNetV2 backbone -----------------
try:
    from torchvision.models import (
        shufflenet_v2_x0_5, shufflenet_v2_x1_0, shufflenet_v2_x1_5, shufflenet_v2_x2_0
    )
    from torchvision.models.shufflenetv2 import (
        ShuffleNet_V2_X0_5_Weights, ShuffleNet_V2_X1_0_Weights,
        ShuffleNet_V2_X1_5_Weights, ShuffleNet_V2_X2_0_Weights
    )
    _HAS_TV = True
except Exception:
    _HAS_TV = False


# ----------------- 基础算子 -----------------
class ConvBNAct(nn.Module):
    def __init__(self, c1, c2, k=1, s=1, p=None, groups=1, act=True):
        super().__init__()
        if p is None:
            p = (k - 1) // 2
        self.conv = nn.Conv2d(c1, c2, k, s, p, groups=groups, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU(inplace=True) if act else nn.Identity()

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))


class SeparableConv2d(nn.Module):
    """DWConv + PWConv（轻量）"""
    def __init__(self, c, k=3, s=1, d=1, act=True):
        super().__init__()
        p = d * (k - 1) // 2
        self.dw = nn.Conv2d(c, c, k, s, p, groups=c, dilation=d, bias=False)
        self.bn1 = nn.BatchNorm2d(c)
        self.pw = nn.Conv2d(c, c, 1, 1, 0, bias=False)
        self.bn2 = nn.BatchNorm2d(c)
        self.act = nn.SiLU(inplace=True) if act else nn.Identity()

    def forward(self, x):
        x = self.act(self.bn1(self.dw(x)))
        x = self.act(self.bn2(self.pw(x)))
        return x


def resize_to(x, ref, mode="nearest"):
    return x if x.shape[-2:] == ref.shape[-2:] else F.interpolate(x, size=ref.shape[-2:], mode=mode)


# ----------------- HKM：Hybrid Kernel Mixer（多感受野核选择） -----------------
class HKM(nn.Module):
    """
    并行 DWConv(k=3,d=1) 与 DWConv(k=3,d=d2)，用软门控自适应融合，再 1×1 混合。
    """
    def __init__(self, c: int, d2: int = 2):
        super().__init__()
        self.br1 = SeparableConv2d(c, k=3, d=1)
        self.br2 = SeparableConv2d(c, k=3, d=d2)
        cr = max(c // 16, 1)
        self.gate = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(c, cr, 1, bias=False), nn.ReLU(inplace=True),
            nn.Conv2d(cr, 2, 1, bias=True)
        )
        self.mix = ConvBNAct(c, c, k=1)

    def forward(self, x):
        a = self.br1(x)
        b = self.br2(x)
        w = torch.softmax(self.gate(x), dim=1)    # [B,2,1,1]
        y = w[:, 0:1] * a + w[:, 1:2] * b
        return self.mix(y)


# ----------------- CSGF：Cross-Scale Graph Fusion -----------------
class CSGFLayer(nn.Module):
    """
    基于样本内容自适应地计算 3×3 邻接 A（目标 i 从源 j 收消息），进行跨尺度融合；可选 HKM 强化。
    """
    def __init__(self, c: int, use_hkm: bool = True):
        super().__init__()
        d = max(c // 4, 8)  # 嵌入维度
        self.embed = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(c, d, 1, bias=False), nn.SiLU(inplace=True),
            nn.Conv2d(d, d, 1, bias=False)
        )
        self.tau = nn.Parameter(torch.tensor(1.0))  # 温度
        self.src_proj = nn.ModuleList([ConvBNAct(c, c, k=1) for _ in range(3)])
        self.tgt_hkm = nn.ModuleList([HKM(c) if use_hkm else nn.Identity() for _ in range(3)])
        self.res_gamma = nn.Parameter(torch.tensor(1.0))

    def forward(self, P3, P4, P5):
        feats = [P3, P4, P5]
        embs = [self.embed(f).flatten(1) for f in feats]         # [B,d]
        E = torch.stack(embs, dim=1)                              # [B,3,d]
        d = E.shape[-1]
        # A[i,j] = softmax_j( <e_i, e_j> / (sqrt(d)*tau) )
        sim = torch.einsum("bid,bjd->bij", E, E) / (math.sqrt(d) * torch.clamp(self.tau, min=1e-3))
        A = torch.softmax(sim, dim=2)                             # [B,3,3]

        S = [self.src_proj[k](feats[k]) for k in range(3)]
        outs = []
        for i, ref in enumerate(feats):
            fused = 0.0
            for j, src in enumerate(S):
                w_ij = A[:, i, j].view(-1, 1, 1, 1)
                fused = fused + w_ij * resize_to(src, ref)
            fused = fused + self.res_gamma * ref
            fused = self.tgt_hkm[i](fused)
            outs.append(fused)
        return outs[0], outs[1], outs[2]


class CSGF(nn.Module):
    def __init__(self, c: int, repeats: int = 2, use_hkm: bool = True):
        super().__init__()
        self.layers = nn.ModuleList([CSGFLayer(c, use_hkm=use_hkm) for _ in range(repeats)])

    def forward(self, P3, P4, P5):
        for m in self.layers:
            P3, P4, P5 = m(P3, P4, P5)
        return P3, P4, P5


# ----------------- 尺度选择器 -----------------
class ScaleSelector(nn.Module):
    """
    mode:
      - 'softmax'：学习到的软选择（默认）
      - 'fixed'  ：仅输出 out_scale 对应尺度
      - 'avg'    ：三尺度对齐后简单平均
    """
    def __init__(self, c: int, out_scale: str = "P3", mode: str = "softmax"):
        super().__init__()
        assert out_scale in ("P3", "P4", "P5")
        assert mode in ("softmax", "fixed", "avg")
        self.out_scale = out_scale
        self.mode = mode
        cr = max(c // 16, 1)
        self.score = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(c, cr, 1, bias=False), nn.ReLU(inplace=True),
            nn.Conv2d(cr, 1, 1, bias=True)
        )

    def forward(self, P3, P4, P5):
        if self.mode == "fixed":
            return {"P3": P3, "P4": P4, "P5": P5}[self.out_scale]
        elif self.mode == "avg":
            ref = {"P3": P3, "P4": P4, "P5": P5}[self.out_scale]
            P3r, P4r, P5r = resize_to(P3, ref), resize_to(P4, ref), resize_to(P5, ref)
            return (P3r + P4r + P5r) / 3.0
        else:
            # softmax
            s3 = self.score(P3); s4 = self.score(P4); s5 = self.score(P5)
            w = torch.softmax(torch.cat([s3, s4, s5], dim=1), dim=1)  # [B,3,1,1]
            if self.out_scale == "P3":
                ref = P3; P4r, P5r = resize_to(P4, ref), resize_to(P5, ref)
                out = w[:,0:1]*P3 + w[:,1:2]*P4r + w[:,2:3]*P5r
            elif self.out_scale == "P4":
                ref = P4; P3r, P5r = resize_to(P3, ref), resize_to(P5, ref)
                out = w[:,0:1]*P3r + w[:,1:2]*P4 + w[:,2:3]*P5r
            else:
                ref = P5; P3r, P4r = resize_to(P3, ref), resize_to(P4, ref)
                out = w[:,0:1]*P3r + w[:,1:2]*P4r + w[:,2:3]*P5
            return out


# ----------------- 主模块：SV2 + CSGF + HKM（含消融开关） -----------------
class SV2_CSGF_HKM_abla(nn.Module):
    """
    YAML 作为 backbone 调用：
      [-1, 1, SV2_CSGF_HKM, [c2, width_mult, pretrained_backbone, repeats, out_scale, selector_mode, use_hkm]]
    解析对齐：
      - self.width_list = [0, c2, c2, c2, c2]
      - forward() 返回 [None, P3', P4', P5', Out]
    """
    def __init__(self,
                 c2: int = 256,
                 width_mult: float = 1.0,
                 pretrained_backbone: bool = False,
                 repeats: int = 2,
                 out_scale: str = "P3",
                 selector_mode: str = "softmax",
                 use_hkm: bool = True,
                 c1: int = 3):  # c1 保留以兼容某些解析器签名
        super().__init__()
        if not _HAS_TV:
            raise ImportError("需要 torchvision，请先 `pip install torchvision`。")

        self.c2 = c2
        self.width_mult = float(width_mult)

        # 1) 选择 ShuffleNetV2
        if abs(self.width_mult - 0.5) < 1e-6:
            weights = ShuffleNet_V2_X0_5_Weights.DEFAULT if pretrained_backbone else None
            m = shufflenet_v2_x0_5(weights=weights)
        elif abs(self.width_mult - 1.0) < 1e-6:
            weights = ShuffleNet_V2_X1_0_Weights.DEFAULT if pretrained_backbone else None
            m = shufflenet_v2_x1_0(weights=weights)
        elif abs(self.width_mult - 1.5) < 1e-6:
            weights = ShuffleNet_V2_X1_5_Weights.DEFAULT if pretrained_backbone else None
            m = shufflenet_v2_x1_5(weights=weights)
        elif abs(self.width_mult - 2.0) < 1e-6:
            weights = ShuffleNet_V2_X2_0_Weights.DEFAULT if pretrained_backbone else None
            m = shufflenet_v2_x2_0(weights=weights)
        else:
            raise ValueError(f"不支持的 width_mult={width_mult}，可选 0.5/1.0/1.5/2.0")

        # 2) stages
        self.stem = nn.Sequential(m.conv1, m.maxpool)  # /4
        self.stage2 = m.stage2                          # /8
        self.stage3 = m.stage3                          # /16
        self.stage4 = m.stage4                          # /32
        self.conv5  = m.conv5                           # /32

        # 3) 懒构建通道适配
        self.adapt3: Optional[nn.Module] = None
        self.adapt4: Optional[nn.Module] = None
        self.adapt5: Optional[nn.Module] = None

        # 4) 融合与选择（含消融开关）
        repeats = max(int(repeats), 0)
        if repeats > 0:
            self.csgf = CSGF(c=c2, repeats=repeats, use_hkm=use_hkm)
        else:
            self.csgf = None  # 关闭 CSGF（消融）
        self.selector = ScaleSelector(c=c2, out_scale=out_scale, mode=selector_mode)
        self.out_bn = nn.BatchNorm2d(c2)

        # 5) 供 parse_model 使用（长度5以对齐你的解析器）
        self.width_list = [0, self.c2, self.c2, self.c2, self.c2]

    def _build_adapters(self, c3, c4, c5, device):
        self.adapt3 = ConvBNAct(c3, self.c2, k=1, act=True).to(device)
        self.adapt4 = ConvBNAct(c4, self.c2, k=1, act=True).to(device)
        self.adapt5 = ConvBNAct(c5, self.c2, k=1, act=True).to(device)

    def forward(self, x):
        # Backbone
        x = self.stem(x)        # /4
        P3 = self.stage2(x)     # /8
        P4 = self.stage3(P3)    # /16
        P5 = self.stage4(P4)    # /32
        P5 = self.conv5(P5)     # /32

        # 适配通道
        if self.adapt3 is None:
            self._build_adapters(P3.shape[1], P4.shape[1], P5.shape[1], device=P3.device)
        P3a = self.adapt3(P3)
        P4a = self.adapt4(P4)
        P5a = self.adapt5(P5)

        # 融合（可关）
        if self.csgf is None:
            P3b, P4b, P5b = P3a, P4a, P5a
        else:
            P3b, P4b, P5b = self.csgf(P3a, P4a, P5a)

        # 尺度选择与归一化
        Out = self.selector(P3b, P4b, P5b)
        Out = self.out_bn(Out)

        # 返回 backbone 约定的五项列表
        return [None, P3b, P4b, P5b, Out]
