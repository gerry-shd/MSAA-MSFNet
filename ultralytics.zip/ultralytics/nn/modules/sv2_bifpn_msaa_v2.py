# ultralytics/nn/modules/sv2_bifpn_msaa.py
# -*- coding: utf-8 -*-
"""
ShuffleNetV2 多层特征 + BiFPN + 多尺度自适应注意力（MSAA） → 分类前特征
输出为一个统一通道数的特征图，后接 Ultralytics 的 Classify 头。
"""

from typing import Optional
import torch
import torch.nn as nn
import torch.nn.functional as F

# --- torchvision shufflenetv2 作为骨干 ---
try:
    from torchvision.models import (
        shufflenet_v2_x0_5, shufflenet_v2_x1_0, shufflenet_v2_x1_5, shufflenet_v2_x2_0
    )
    from torchvision.models.shufflenetv2 import (
        ShuffleNet_V2_X0_5_Weights, ShuffleNet_V2_X1_0_Weights,
        ShuffleNet_V2_X1_5_Weights, ShuffleNet_V2_X2_0_Weights
    )
    _HAS_TV = True
except Exception:
    _HAS_TV = False


# -----------------------
# 基础模块
# -----------------------
class ConvBNAct(nn.Module):
    def __init__(self, c1, c2, k=1, s=1, p=None, groups=1, act=True):
        super().__init__()
        if p is None:
            p = (k - 1) // 2
        self.conv = nn.Conv2d(c1, c2, k, s, p, groups=groups, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU(inplace=True) if act else nn.Identity()

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))


class SeparableConv2d(nn.Module):
    """DWConv + PWConv（BiFPN常用）"""
    def __init__(self, c, k=3, s=1, act=True):
        super().__init__()
        p = (k - 1) // 2
        self.dw = nn.Conv2d(c, c, k, s, p, groups=c, bias=False)
        self.bn1 = nn.BatchNorm2d(c)
        self.pw = nn.Conv2d(c, c, 1, 1, 0, bias=False)
        self.bn2 = nn.BatchNorm2d(c)
        self.act = nn.SiLU(inplace=True) if act else nn.Identity()

        # Kaiming init（与 nn.Conv2d 默认一致，可省略；此处保持显式）
        nn.init.kaiming_normal_(self.dw.weight, mode='fan_out', nonlinearity='relu')
        nn.init.kaiming_normal_(self.pw.weight, mode='fan_out', nonlinearity='relu')

    def forward(self, x):
        x = self.act(self.bn1(self.dw(x)))
        x = self.act(self.bn2(self.pw(x)))
        return x


def resize_to(x, ref, mode="nearest"):
    """把 x 调整到与 ref 同 HxW"""
    if x.shape[-2:] == ref.shape[-2:]:
        return x
    return F.interpolate(x, size=ref.shape[-2:], mode=mode)


# -----------------------
# BiFPN（3层特征版本）
# -----------------------
class BiFPNLayer(nn.Module):
    """
    单层 BiFPN，融合 P3,P4,P5（三个尺度）。
    采用可学习融合权重（softplus 保证非负） + 深度可分离卷积。
    """
    def __init__(self, c: int, epsilon: float = 1e-4):
        super().__init__()
        self.epsilon = epsilon

        # 融合权重（top-down / bottom-up）
        self.w1 = nn.Parameter(torch.ones(2, 3))
        self.w2 = nn.Parameter(torch.ones(2, 2))

        self.p3_out = SeparableConv2d(c)
        self.p4_td = SeparableConv2d(c)
        self.p5_td = SeparableConv2d(c)

        self.p4_out = SeparableConv2d(c)
        self.p3_out2 = SeparableConv2d(c)

        self.softplus = nn.Softplus()

    def _norm_weights(self, ws: torch.Tensor):
        w = self.softplus(ws)
        return w / (w.sum(dim=0, keepdim=True) + self.epsilon)

    def forward(self, P3, P4, P5):
        # ---------- top-down ----------
        w = self._norm_weights(self.w1)
        P4_td_in = w[0, 0] * P4 + w[1, 0] * resize_to(P5, P4)
        P4_td = self.p4_td(P4_td_in)

        P3_td_in = w[0, 1] * P3 + w[1, 1] * resize_to(P4_td, P3)
        P3_td = self.p3_out(P3_td_in)

        # ---------- bottom-up ----------
        w2 = self._norm_weights(self.w2)
        P4_out_in = w2[0, 0] * P4 + w2[1, 0] * resize_to(P3_td, P4)
        P4_out = self.p4_out(P4_out_in)

        P3_out_in = w2[0, 1] * P3_td + w2[1, 1] * resize_to(P4_out, P3)
        P3_out2 = self.p3_out2(P3_out_in)

        return P3_out2, P4_out, P5  # P5 未变，可继续多层堆叠


class BiFPN(nn.Module):
    def __init__(self, c: int, repeats: int = 2):
        super().__init__()
        self.layers = nn.ModuleList([BiFPNLayer(c) for _ in range(repeats)])

    def forward(self, P3, P4, P5):
        for m in self.layers:
            P3, P4, P5 = m(P3, P4, P5)
        return P3, P4, P5


# -----------------------
# 多尺度自适应注意力（MSAA）
# -----------------------
class MSAA(nn.Module):
    def __init__(self, c: int, r: int = 16, out_scale: str = "P3"):
        super().__init__()
        cr = max(c // r, 1)
        self.scale_squeeze = nn.ModuleList([
            nn.Sequential(nn.AdaptiveAvgPool2d(1), nn.Conv2d(c, 1, 1, bias=True))
            for _ in range(3)
        ])
        self.se = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(c, cr, 1, bias=False), nn.ReLU(inplace=True),
            nn.Conv2d(cr, c, 1, bias=False), nn.Sigmoid()
        )
        assert out_scale in ("P3", "P4", "P5")
        self.out_scale = out_scale

    def forward(self, P3, P4, P5):
        feats = [P3, P4, P5]
        scores = [s(f).flatten(1) for s, f in zip(self.scale_squeeze, feats)]  # [B,1] ×3
        scores = torch.cat(scores, dim=1)  # [B,3]
        alpha = scores.softmax(dim=1).unsqueeze(-1).unsqueeze(-1)  # [B,3,1,1]
        feats = [f * self.se(f) for f in feats]

        if self.out_scale == "P3":
            ref = feats[0]
            resized = [feats[0], resize_to(feats[1], ref, "nearest"), resize_to(feats[2], ref, "nearest")]
        elif self.out_scale == "P4":
            ref = feats[1]
            resized = [resize_to(feats[0], ref, "nearest"), feats[1], resize_to(feats[2], ref, "nearest")]
        else:
            ref = feats[2]
            resized = [resize_to(feats[0], ref, "nearest"), resize_to(feats[1], ref, "nearest"), feats[2]]

        out = alpha[:, 0:1] * resized[0] + alpha[:, 1:2] * resized[1] + alpha[:, 2:3] * resized[2]
        return out


# -----------------------
# ShuffleNetV2 多层特征抽取 + 适配 + BiFPN + MSAA
# 输出：统一通道数的单尺度特征图（给 Classify 使用）
# -----------------------
class SV2_BiFPN_MSAA_V2(nn.Module):
    def __init__(self,
                 c2: int = 256,
                 width_mult: float = 1.0,
                 pretrained_backbone: bool = False,
                 bifpn_repeats: int = 2,
                 out_scale: str = "P3",
                 c1: int = 3):  # 占位，不用
        super().__init__()
        if not _HAS_TV:
            raise ImportError("需要 torchvision，请先 `pip install torchvision`。")

        self.c2 = c2
        self.width_list = [0, self.c2, self.c2, self.c2, self.c2]
        self.width_mult = float(width_mult)

        # 1) 选择合适的 ShuffleNetV2 构造器
        if abs(self.width_mult - 0.5) < 1e-6:
            weights = ShuffleNet_V2_X0_5_Weights.DEFAULT if pretrained_backbone else None
            m = shufflenet_v2_x0_5(weights=weights)
        elif abs(self.width_mult - 1.0) < 1e-6:
            weights = ShuffleNet_V2_X1_0_Weights.DEFAULT if pretrained_backbone else None
            m = shufflenet_v2_x1_0(weights=weights)
        elif abs(self.width_mult - 1.5) < 1e-6:
            weights = ShuffleNet_V2_X1_5_Weights.DEFAULT if pretrained_backbone else None
            m = shufflenet_v2_x1_5(weights=weights)
        elif abs(self.width_mult - 2.0) < 1e-6:
            weights = ShuffleNet_V2_X2_0_Weights.DEFAULT if pretrained_backbone else None
            m = shufflenet_v2_x2_0(weights=weights)
        else:
            raise ValueError(f"不支持的 width_mult={width_mult}，可选 0.5/1.0/1.5/2.0")

        # 2) backbone stages
        self.stem = nn.Sequential(m.conv1, m.maxpool)  # /4
        self.stage2 = m.stage2                          # /8
        self.stage3 = m.stage3                          # /16
        self.stage4 = m.stage4                          # /32
        self.conv5  = m.conv5                           # /32

        # 3) 用一次“干跑”推断 P3/P4/P5 通道数 → 立即构建适配层（参数已初始化，优化器可见）
        c3, c4, c5 = self._infer_backbone_channels()
        self.adapt3 = ConvBNAct(c3, self.c2, k=1, act=True)
        self.adapt4 = ConvBNAct(c4, self.c2, k=1, act=True)
        self.adapt5 = ConvBNAct(c5, self.c2, k=1, act=True)

        # 4) BiFPN + MSAA
        self.bifpn = BiFPN(c=c2, repeats=bifpn_repeats)
        self.msaa = MSAA(c=c2, r=16, out_scale=out_scale)
        self.out_bn = nn.BatchNorm2d(c2)

    @torch.no_grad()
    def _infer_backbone_channels(self):
        """在 __init__ 阶段用 CPU 上的一次干跑，推断 P3/P4/P5 的通道数。"""
        # 说明：用 eval() 且 no_grad()，不会改 BN 的 running stats
        training_flags = {}
        mods = [self.stem, self.stage2, self.stage3, self.stage4, self.conv5]
        for m in mods:
            training_flags[m] = m.training
            m.eval()

        x = torch.zeros(1, 3, 224, 224)   # 与 ImageNet 预训练分辨率一致
        x = self.stem(x)                   # /4
        P3 = self.stage2(x)                # /8
        P4 = self.stage3(P3)               # /16
        P5 = self.stage4(P4)               # /32
        P5 = self.conv5(P5)                # /32

        c3, c4, c5 = P3.shape[1], P4.shape[1], P5.shape[1]

        # 还原模块的训练状态
        for m in mods:
            if training_flags[m]:
                m.train()
            else:
                m.eval()

        # 显式释放临时张量
        del x, P3, P4, P5
        return c3, c4, c5

    def forward(self, x):
        # 1) backbone stages
        x = self.stem(x)        # /4
        P3 = self.stage2(x)     # /8
        P4 = self.stage3(P3)    # /16
        P5 = self.stage4(P4)    # /32
        P5 = self.conv5(P5)     # /32

        # 2) 通道对齐到 c2
        P3a = self.adapt3(P3)
        P4a = self.adapt4(P4)
        P5a = self.adapt5(P5)

        # 3) BiFPN 融合
        P3b, P4b, P5b = self.bifpn(P3a, P4a, P5a)

        # 4) 多尺度自适应注意力 + 输出 BN
        Out = self.msaa(P3b, P4b, P5b)
        Out = self.out_bn(Out)

        # 作为“backbone 模块”的输出，必须返回 list（长度 5）
        # 索引约定：0 占位（None），1→P3，2→P4，3→P5，4→主输出（给下一层）
        return [None, P3b, P4b, P5b, Out]
