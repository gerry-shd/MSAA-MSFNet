# ultralytics/nn/modules/sv2_bifpn_msaa.py
# -*- coding: utf-8 -*-
"""
ShuffleNetV2 多层特征 + BiFPN + 多尺度自适应注意力（MSAA） → 分类前特征
输出为一个统一通道数的特征图，后接 Ultralytics 的 Classify 头。
"""

import math
from typing import List, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

# --- 顶部导入，替换原来的 shufflenet 导入 ---
try:
    from torchvision.models import (
        shufflenet_v2_x0_5, shufflenet_v2_x1_0, shufflenet_v2_x1_5, shufflenet_v2_x2_0
    )
    from torchvision.models.shufflenetv2 import (
        ShuffleNet_V2_X0_5_Weights, ShuffleNet_V2_X1_0_Weights,
        ShuffleNet_V2_X1_5_Weights, ShuffleNet_V2_X2_0_Weights
    )
    _HAS_TV = True
except Exception:
    _HAS_TV = False


# -----------------------
# 基础模块
# -----------------------
class ConvBNAct(nn.Module):
    def __init__(self, c1, c2, k=1, s=1, p=None, groups=1, act=True):
        super().__init__()
        if p is None:
            p = (k - 1) // 2
        self.conv = nn.Conv2d(c1, c2, k, s, p, groups=groups, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU(inplace=True) if act else nn.Identity()

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))


class SeparableConv2d(nn.Module):
    """DWConv + PWConv（BiFPN常用）"""
    def __init__(self, c, k=3, s=1, act=True):
        super().__init__()
        p = (k - 1) // 2
        self.dw = nn.Conv2d(c, c, k, s, p, groups=c, bias=False)
        self.bn1 = nn.BatchNorm2d(c)
        self.pw = nn.Conv2d(c, c, 1, 1, 0, bias=False)
        self.bn2 = nn.BatchNorm2d(c)
        self.act = nn.SiLU(inplace=True) if act else nn.Identity()

    def forward(self, x):
        x = self.act(self.bn1(self.dw(x)))
        x = self.act(self.bn2(self.pw(x)))
        return x


def resize_to(x, ref, mode="nearest"):
    """把 x 调整到与 ref 同 HxW"""
    if x.shape[-2:] == ref.shape[-2:]:
        return x
    return F.interpolate(x, size=ref.shape[-2:], mode=mode)


# -----------------------
# BiFPN（3层特征版本）
# -----------------------
class BiFPNLayer(nn.Module):
    """
    单层 BiFPN，融合 P3,P4,P5（三个尺度）。
    采用可学习融合权重（softplus 保证非负） + 深度可分离卷积。
    """
    def __init__(self, c: int, epsilon: float = 1e-4):
        super().__init__()
        self.epsilon = epsilon

        # 融合权重（top-down / bottom-up）
        self.w1 = nn.Parameter(torch.ones(2, 3))  # 2个方向，每个方向对三个融合点各有2个权重
        self.w2 = nn.Parameter(torch.ones(2, 2))

        # 上采样/下采样 conv（可选，这里直接用插值）
        self.p3_out = SeparableConv2d(c)
        self.p4_td = SeparableConv2d(c)
        self.p5_td = SeparableConv2d(c)

        self.p4_out = SeparableConv2d(c)
        self.p3_out2 = SeparableConv2d(c)

        # 为稳定起见使用 softplus 确保权重≥0
        self.softplus = nn.Softplus()

    def _norm_weights(self, ws: torch.Tensor):
        w = self.softplus(ws)
        return w / (w.sum(dim=0, keepdim=True) + self.epsilon)

    def forward(self, P3, P4, P5):
        # ---------- top-down ----------
        # P5_td = P5
        w = self._norm_weights(self.w1)
        # 节点1：P4_td = conv( w0 * P4 + w1 * resize(P5) )
        P4_td_in = w[0, 0] * P4 + w[1, 0] * resize_to(P5, P4)
        P4_td = self.p4_td(P4_td_in)

        # 节点2：P3_td = conv( w0 * P3 + w1 * resize(P4_td) )
        P3_td_in = w[0, 1] * P3 + w[1, 1] * resize_to(P4_td, P3)
        P3_td = self.p3_out(P3_td_in)

        # ---------- bottom-up ----------
        w2 = self._norm_weights(self.w2)
        # 节点3：P4_out = conv( w0 * P4 + w1 * resize(P3_td, P4) )
        P4_out_in = w2[0, 0] * P4 + w2[1, 0] * resize_to(P3_td, P4)
        P4_out = self.p4_out(P4_out_in)

        # 节点4：P3_out2 = conv( w0 * P3_td + w1 * resize(P4_out, P3) )
        P3_out_in = w2[0, 1] * P3_td + w2[1, 1] * resize_to(P4_out, P3)
        P3_out2 = self.p3_out2(P3_out_in)

        # 返回三个尺度（你也可以只返回一个主尺度）
        return P3_out2, P4_out, P5  # P5 未变，可继续多层堆叠


class BiFPN(nn.Module):
    def __init__(self, c: int, repeats: int = 2):
        super().__init__()
        self.layers = nn.ModuleList([BiFPNLayer(c) for _ in range(repeats)])

    def forward(self, P3, P4, P5):
        for m in self.layers:
            P3, P4, P5 = m(P3, P4, P5)
        return P3, P4, P5


# -----------------------
# 多尺度自适应注意力（MSAA）
# 思路：跨尺度权重 + 通道注意力（SE）
# -----------------------
class MSAA(nn.Module):
    def __init__(self, c: int, r: int = 16, out_scale: str = "P3"):
        super().__init__()
        cr = max(c // r, 1)
        # 每个尺度提取一个标量用于跨尺度 softmax
        self.scale_squeeze = nn.ModuleList([
            nn.Sequential(nn.AdaptiveAvgPool2d(1), nn.Conv2d(c, 1, 1, bias=True))
            for _ in range(3)
        ])
        # 通道注意力（共享）
        self.se = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(c, cr, 1, bias=False), nn.ReLU(inplace=True),
            nn.Conv2d(cr, c, 1, bias=False), nn.Sigmoid()
        )
        assert out_scale in ("P3", "P4", "P5")
        self.out_scale = out_scale

    def forward(self, P3, P4, P5):
        feats = [P3, P4, P5]
        # 跨尺度权重
        scores = [s(f).flatten(1) for s, f in zip(self.scale_squeeze, feats)]  # [B,1]
        scores = torch.cat(scores, dim=1)  # [B,3]
        alpha = scores.softmax(dim=1).unsqueeze(-1).unsqueeze(-1)  # [B,3,1,1]
        # 通道注意力
        feats = [f * self.se(f) for f in feats]
        # 统一到输出尺度后做加权融合
        if self.out_scale == "P3":
            ref = feats[0]
            resized = [feats[0], resize_to(feats[1], ref, "nearest"), resize_to(feats[2], ref, "nearest")]
        elif self.out_scale == "P4":
            ref = feats[1]
            resized = [resize_to(feats[0], ref, "nearest"), feats[1], resize_to(feats[2], ref, "nearest")]
        else:
            ref = feats[2]
            resized = [resize_to(feats[0], ref, "nearest"), resize_to(feats[1], ref, "nearest"), feats[2]]
        # 权重相乘后求和
        out = alpha[:, 0:1] * resized[0] + alpha[:, 1:2] * resized[1] + alpha[:, 2:3] * resized[2]
        return out


# -----------------------
# ShuffleNetV2 多层特征抽取 + 适配 + BiFPN + MSAA
# 输出：统一通道数的单尺度特征图（给 Classify 使用）
# -----------------------
class SV2_BiFPN_MSAA(nn.Module):
    def __init__(self,
                 c2: int = 256,
                 width_mult: float = 1.0,
                 pretrained_backbone: bool = False,
                 bifpn_repeats: int = 2,
                 out_scale: str = "P3",
                 c1: int = 3):  # 占位，不用
        super().__init__()
        if not _HAS_TV:
            raise ImportError("需要 torchvision，请先 `pip install torchvision`。")

        self.c2 = c2
        self.width_list = [0, self.c2, self.c2, self.c2, self.c2]
        self.width_mult = float(width_mult)

        # 1) 选择合适的 ShuffleNetV2 构造器
        if abs(self.width_mult - 0.5) < 1e-6:
            weights = ShuffleNet_V2_X0_5_Weights.DEFAULT if pretrained_backbone else None
            m = shufflenet_v2_x0_5(weights=weights)
        elif abs(self.width_mult - 1.0) < 1e-6:
            weights = ShuffleNet_V2_X1_0_Weights.DEFAULT if pretrained_backbone else None
            m = shufflenet_v2_x1_0(weights=weights)
        elif abs(self.width_mult - 1.5) < 1e-6:
            weights = ShuffleNet_V2_X1_5_Weights.DEFAULT if pretrained_backbone else None
            m = shufflenet_v2_x1_5(weights=weights)
        elif abs(self.width_mult - 2.0) < 1e-6:
            weights = ShuffleNet_V2_X2_0_Weights.DEFAULT if pretrained_backbone else None
            m = shufflenet_v2_x2_0(weights=weights)
        else:
            raise ValueError(f"不支持的 width_mult={width_mult}，可选 0.5/1.0/1.5/2.0")

        # 2) backbone stages
        self.stem = nn.Sequential(m.conv1, m.maxpool)  # /4
        self.stage2 = m.stage2                          # /8
        self.stage3 = m.stage3                          # /16
        self.stage4 = m.stage4                          # /32
        self.conv5  = m.conv5                           # /32

        # 3) 适配层延迟构建（首次 forward 再按真实通道数创建）
        self.adapt3 = None
        self.adapt4 = None
        self.adapt5 = None

        # 4) BiFPN + MSAA（与原实现相同）
        self.bifpn = BiFPN(c=c2, repeats=bifpn_repeats)
        self.msaa = MSAA(c=c2, r=16, out_scale=out_scale)
        self.out_bn = nn.BatchNorm2d(c2)

    def _build_adapters(self, c3, c4, c5, device):
        # 在第一次前向时根据实际通道构建 1x1 适配层
        self.adapt3 = ConvBNAct(c3, self.c2, k=1, act=True).to(device)
        self.adapt4 = ConvBNAct(c4, self.c2, k=1, act=True).to(device)
        self.adapt5 = ConvBNAct(c5, self.c2, k=1, act=True).to(device)

    def forward(self, x):
        # 1) backbone stages
        x = self.stem(x)        # /4
        P3 = self.stage2(x)     # /8
        P4 = self.stage3(P3)    # /16
        P5 = self.stage4(P4)    # /32
        P5 = self.conv5(P5)     # /32

        # 2) 懒构建 1x1 适配层（如果你已经这样做了，可保留原写法）
        if self.adapt3 is None:
            self._build_adapters(P3.shape[1], P4.shape[1], P5.shape[1], device=P3.device)

        # 3) 通道对齐到 c2
        P3a = self.adapt3(P3)
        P4a = self.adapt4(P4)
        P5a = self.adapt5(P5)

        # 4) BiFPN 融合（仍保留 3 个尺度）
        P3b, P4b, P5b = self.bifpn(P3a, P4a, P5a)

        # 5) 多尺度自适应注意力，得到主输出
        Out = self.msaa(P3b, P4b, P5b)
        Out = self.out_bn(Out)

        # ★★★★★ 关键：作为“backbone 模块”的输出，必须返回 list（长度 5）
        # 索引约定：0 占位（None），1→P3，2→P4，3→P5，4→主输出（给下一层）
        return [None, P3b, P4b, P5b, Out]

