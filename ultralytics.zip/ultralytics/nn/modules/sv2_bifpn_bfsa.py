# ultralytics/nn/modules/sv2_bifpn_bfsa.py
# -*- coding: utf-8 -*-
import math
from typing import List, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

# ------------- ShuffleNetV2 构造器 -------------
try:
    from torchvision.models import (
        shufflenet_v2_x0_5, shufflenet_v2_x1_0, shufflenet_v2_x1_5, shufflenet_v2_x2_0
    )
    from torchvision.models.shufflenetv2 import (
        ShuffleNet_V2_X0_5_Weights, ShuffleNet_V2_X1_0_Weights,
        ShuffleNet_V2_X1_5_Weights, ShuffleNet_V2_X2_0_Weights
    )
    _HAS_TV = True
except Exception:
    _HAS_TV = False


# ------------- 小工具层 -------------
class ConvBNAct(nn.Module):
    def __init__(self, c1, c2, k=1, s=1, p=None, groups=1, act=True):
        super().__init__()
        if p is None:
            p = (k - 1) // 2
        self.conv = nn.Conv2d(c1, c2, k, s, p, groups=groups, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU(inplace=True) if act else nn.Identity()

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))


class SeparableConv2d(nn.Module):
    """DWConv + PWConv（BiFPN 常用）"""
    def __init__(self, c, k=3, s=1, act=True):
        super().__init__()
        p = (k - 1) // 2
        self.dw = nn.Conv2d(c, c, k, s, p, groups=c, bias=False)
        self.bn1 = nn.BatchNorm2d(c)
        self.pw = nn.Conv2d(c, c, 1, 1, 0, bias=False)
        self.bn2 = nn.BatchNorm2d(c)
        self.act = nn.SiLU(inplace=True) if act else nn.Identity()

    def forward(self, x):
        x = self.act(self.bn1(self.dw(x)))
        x = self.act(self.bn2(self.pw(x)))
        return x


def resize_to(x, ref, mode="nearest"):
    if x.shape[-2:] == ref.shape[-2:]:
        return x
    return F.interpolate(x, size=ref.shape[-2:], mode=mode)


# ------------- BiFPN -------------
class BiFPNLayer(nn.Module):
    def __init__(self, c: int, epsilon: float = 1e-4):
        super().__init__()
        self.epsilon = epsilon

        self.w_top = nn.Parameter(torch.ones(2, 2))   # (for P4_td, P3_td)
        self.w_bot = nn.Parameter(torch.ones(2, 2))   # (for P4_out, P3_out2)
        self.softplus = nn.Softplus()

        self.p4_td = SeparableConv2d(c)
        self.p3_td = SeparableConv2d(c)
        self.p4_out = SeparableConv2d(c)
        self.p3_out2 = SeparableConv2d(c)

    def _norm(self, w):
        w = self.softplus(w)
        return w / (w.sum(dim=0, keepdim=True) + self.epsilon)

    def forward(self, P3, P4, P5):
        wt = self._norm(self.w_top)
        P4_td = self.p4_td(wt[0, 0] * P4 + wt[1, 0] * resize_to(P5, P4))
        P3_td = self.p3_td(wt[0, 1] * P3 + wt[1, 1] * resize_to(P4_td, P3))

        wb = self._norm(self.w_bot)
        P4_out = self.p4_out(wb[0, 0] * P4 + wb[1, 0] * resize_to(P3_td, P4))
        P3_out2 = self.p3_out2(wb[0, 1] * P3_td + wb[1, 1] * resize_to(P4_out, P3))
        return P3_out2, P4_out, P5


class BiFPN(nn.Module):
    def __init__(self, c: int, repeats: int = 2):
        super().__init__()
        self.layers = nn.ModuleList([BiFPNLayer(c) for _ in range(repeats)])

    def forward(self, P3, P4, P5):
        for m in self.layers:
            P3, P4, P5 = m(P3, P4, P5)
        return P3, P4, P5


# ------------- 频域—空域双注意力 -------------
class SpecAttn(nn.Module):
    """
    频域注意力：rFFT 幅度谱 -> GAP -> 1x1 两层感知 -> Sigmoid
    与 SE 空域门控做可学习融合（alpha）
    """
    def __init__(self, c: int, r: int = 16):
        super().__init__()
        cr = max(c // r, 1)
        self.se_spatial = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(c, cr, 1, bias=False), nn.ReLU(inplace=True),
            nn.Conv2d(cr, c, 1, bias=False)
        )
        self.se_freq = nn.Sequential(
            nn.Conv2d(c, cr, 1, bias=False), nn.ReLU(inplace=True),
            nn.Conv2d(cr, c, 1, bias=False)
        )
        self.alpha = nn.Parameter(torch.tensor(0.5))  # 频域权重
        self.sig = nn.Sigmoid()

    def forward(self, x):
        # 空域通道描述
        s = self.se_spatial(x)
        # 频域通道描述（幅度谱）
        Xf = torch.fft.rfft2(x, norm='ortho')
        mag = torch.abs(Xf)
        f = F.adaptive_avg_pool2d(mag, 1)  # [B,C,1,1]
        f = self.se_freq(f)
        w = self.sig(s + self.alpha * f)
        return x * w


class ScaleWeights(nn.Module):
    """
    跨尺度选择：对每个尺度给出一个标量分数 -> Softmax
    """
    def __init__(self, c: int, r: int = 16):
        super().__init__()
        cr = max(c // r, 1)
        self.scorer = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(c, cr, 1, bias=False), nn.ReLU(inplace=True),
            nn.Conv2d(cr, 1, 1, bias=True)
        )

    def forward(self, P3, P4, P5):
        s3 = self.scorer(P3)  # [B,1,1,1]
        s4 = self.scorer(P4)
        s5 = self.scorer(P5)
        scores = torch.cat([s3, s4, s5], dim=1)    # [B,3,1,1]
        alpha = F.softmax(scores, dim=1)
        return alpha[:, 0:1], alpha[:, 1:2], alpha[:, 2:3]


class BFSA(nn.Module):
    """
    Bi-level Frequency-Spatial Attention + 跨尺度选择
    """
    def __init__(self, c: int, out_scale: str = "P3"):
        super().__init__()
        self.spec = SpecAttn(c, r=16)
        self.scale_sel = ScaleWeights(c, r=16)
        assert out_scale in ("P3", "P4", "P5")
        self.out_scale = out_scale

    def forward(self, P3, P4, P5):
        P3 = self.spec(P3)
        P4 = self.spec(P4)
        P5 = self.spec(P5)

        a3, a4, a5 = self.scale_sel(P3, P4, P5)
        if self.out_scale == "P3":
            ref = P3
            P4r, P5r = resize_to(P4, ref, "nearest"), resize_to(P5, ref, "nearest")
            out = a3 * P3 + a4 * P4r + a5 * P5r
        elif self.out_scale == "P4":
            ref = P4
            P3r, P5r = resize_to(P3, ref, "nearest"), resize_to(P5, ref, "nearest")
            out = a3 * P3r + a4 * P4 + a5 * P5r
        else:
            ref = P5
            P3r, P4r = resize_to(P3, ref, "nearest"), resize_to(P4, ref, "nearest")
            out = a3 * P3r + a4 * P4r + a5 * P5
        return out


# ------------- 主模块：SV2 + BiFPN + BFSA -------------
class SV2_BiFPN_BFSA(nn.Module):
    """
    YAML 可用模块（作为 backbone 使用）：
      args: [c2, width_mult, pretrained_backbone, bifpn_repeats, out_scale, c1=3]
      - c2: 统一后的通道数（默认 256）
      - width_mult: 0.5 / 1.0 / 1.5 / 2.0
      - pretrained_backbone: 是否加载 ImageNet 预训练
      - bifpn_repeats: BiFPN 堆叠层数
      - out_scale: 'P3' | 'P4' | 'P5'
    约定：
      - self.width_list = [0, c2, c2, c2, c2]
      - forward() 返回 [None, P3b, P4b, P5b, Out]
    """
    def __init__(self,
                 c2: int = 256,
                 width_mult: float = 1.0,
                 pretrained_backbone: bool = False,
                 bifpn_repeats: int = 2,
                 out_scale: str = "P3",
                 c1: int = 3):
        super().__init__()
        if not _HAS_TV:
            raise ImportError("需要 torchvision，请先 `pip install torchvision`。")

        self.c2 = c2
        self.width_mult = float(width_mult)

        # 1) 选择 ShuffleNetV2
        if abs(self.width_mult - 0.5) < 1e-6:
            weights = ShuffleNet_V2_X0_5_Weights.DEFAULT if pretrained_backbone else None
            m = shufflenet_v2_x0_5(weights=weights)
        elif abs(self.width_mult - 1.0) < 1e-6:
            weights = ShuffleNet_V2_X1_0_Weights.DEFAULT if pretrained_backbone else None
            m = shufflenet_v2_x1_0(weights=weights)
        elif abs(self.width_mult - 1.5) < 1e-6:
            weights = ShuffleNet_V2_X1_5_Weights.DEFAULT if pretrained_backbone else None
            m = shufflenet_v2_x1_5(weights=weights)
        elif abs(self.width_mult - 2.0) < 1e-6:
            weights = ShuffleNet_V2_X2_0_Weights.DEFAULT if pretrained_backbone else None
            m = shufflenet_v2_x2_0(weights=weights)
        else:
            raise ValueError(f"不支持的 width_mult={width_mult}，可选 0.5/1.0/1.5/2.0")

        # 2) backbone stages
        self.stem = nn.Sequential(m.conv1, m.maxpool)  # /4
        self.stage2 = m.stage2                          # /8
        self.stage3 = m.stage3                          # /16
        self.stage4 = m.stage4                          # /32
        self.conv5  = m.conv5                           # /32

        # 3) 懒构建通道适配（1x1）
        self.adapt3 = None
        self.adapt4 = None
        self.adapt5 = None

        # 4) BiFPN + BFSA
        self.bifpn = BiFPN(c=c2, repeats=bifpn_repeats)
        self.bfsa  = BFSA(c=c2, out_scale=out_scale)
        self.out_bn = nn.BatchNorm2d(c2)

        # 5) 给 parse_model 的通道列表（与 forward 的 list 对齐）
        self.width_list = [0, self.c2, self.c2, self.c2, self.c2]

    def _build_adapters(self, c3, c4, c5, device):
        self.adapt3 = ConvBNAct(c3, self.c2, k=1, act=True).to(device)
        self.adapt4 = ConvBNAct(c4, self.c2, k=1, act=True).to(device)
        self.adapt5 = ConvBNAct(c5, self.c2, k=1, act=True).to(device)

    def forward(self, x):
        # Backbone
        x = self.stem(x)     # /4
        P3 = self.stage2(x)  # /8
        P4 = self.stage3(P3) # /16
        P5 = self.stage4(P4) # /32
        P5 = self.conv5(P5)  # /32

        # 适配通道
        if self.adapt3 is None:
            self._build_adapters(P3.shape[1], P4.shape[1], P5.shape[1], device=P3.device)

        P3a = self.adapt3(P3)
        P4a = self.adapt4(P4)
        P5a = self.adapt5(P5)

        # BiFPN
        P3b, P4b, P5b = self.bifpn(P3a, P4a, P5a)

        # 频域-空域混合注意力 + BN
        Out = self.bfsa(P3b, P4b, P5b)
        Out = self.out_bn(Out)

        # 作为“backbone”输出：长度5
        return [None, P3b, P4b, P5b, Out]
